package kotiln.biz.book

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BookV2ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
